a = 1
b = 2.2
c = a + b

%%
v1 = 1:5
y1 = sin(v1)

%%
k = 1.2
l = 8.00
m = k * l