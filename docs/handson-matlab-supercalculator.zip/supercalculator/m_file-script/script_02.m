a = 7;
b = sin(5);
d = a * b;