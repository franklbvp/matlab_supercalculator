script_abc

script_xyz