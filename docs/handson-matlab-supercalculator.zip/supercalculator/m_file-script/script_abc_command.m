a = 1
b = 1.2
c = a + b

a < 10