% main script

% call 1
file26

% call 2
file27