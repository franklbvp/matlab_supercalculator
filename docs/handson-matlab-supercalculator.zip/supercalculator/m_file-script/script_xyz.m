%
% here is some information on xyz
% 
% x: single valued variable : needs to set
% y: 
%



x = 1  % set the value
y = 99
a = 999

% calculate the result
z = x + 5 + y + a