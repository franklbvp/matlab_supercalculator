function y = myfun(x)

y = 1./(x.^3-2*x-5)
