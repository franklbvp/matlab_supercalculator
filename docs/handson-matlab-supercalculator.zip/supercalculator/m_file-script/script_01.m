a = 12
b = 34
c = a + b