function [outputArg1,outputArg2] = my_sum(inputArg1,inputArg2)
% my_sum computes the sum of 2 arrays
% 2 results are returned, the sum and the absolute value of the sum
outputArg1 = inpinputArg1 + inputArg2;
outputArg2 = abs(outputArg1);
end

