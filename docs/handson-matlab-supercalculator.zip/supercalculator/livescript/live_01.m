%% 
% this live script is a first test

x = [1:10]
%% 
% here some more values
%% 
% * type 1
% * type 2
%% 
% 
% 
% 

y = sin(x)

plot(x,y)