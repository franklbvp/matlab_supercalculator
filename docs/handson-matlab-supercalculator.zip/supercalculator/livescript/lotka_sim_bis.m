function [yp] = lotka_sim_bis(t,y,p_a, p_b, p_c, p_d)
%LOTKA_sim_bis  Lotka-Volterra predator-prey model.
% this function takes 4 parameter values as input

%   Copyright 1984-2014 The MathWorks, Inc.

yp = diag([p_a - p_b*y(2), p_c*y(1) - p_d])*y;
end