x = [1:10]

y = sin(x)

plot(x,y)
