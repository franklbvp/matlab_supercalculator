a = 1 / 3
b = 7.5
c = a * b