%
% demo_sort_sortrows
%
% based on Holly Moore, Matlab for Engineers 2nd Ed
%

% sort vector
x1 = [1, 5, 3];

sort(x1)
sort(x1, 'descend')

% sort array
x2 = [1 5 3; 2 4 6];

sort(x2)
sort(x2, 'descend')

% sortrow
sortrows(x2)

% sortrow along a column
sortrows(x2,2)
