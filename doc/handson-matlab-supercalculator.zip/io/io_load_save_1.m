%
% example io load / save
% can be written in command format or function format
%
clear
%
a = 1;
b = 2;
c = 3;

%save myvars a b c	% save variables in default mat file 
save ('myvars',  'a', 'b', 'c')	% save variables in default mat file 

%save myvars_no -v6  % A format that MATLAB Version 6 and earlier can open
save ('myvars_no',  '-v6')  % A format that MATLAB Version 6 and earlier can open

clear              	% clear all variables

%load myvars a b     % load "a" en "b" from myvars.mat
load ('myvars', 'a', 'b')     % load "a" en "b" from myvars.mat

d = 5 + 7i;
e = 4 - 9i;

%save -ascii file1  d e
save ('file2',  'd', 'e')
save ('file2_ascii',  'd', 'e', '-ascii')

f = [17 18; 24 25];
%save -append myvars f  % save f at the end of the file
save ('myvars',  'f', '-append')  

% will this work?
save ('file1',  'f', '-append', '-ascii')  % save f at the end of the file

% test with strings
aa = 'word';
bb = 'letter';
save ('file2',  'aa', 'bb', '-append')
save ('file_string_ascii', 'aa', 'bb', '-ascii')

% loading the data back into workspace
% myvars
clear;

whos -file myvars

load myvars

% file2
clear

load file2

% file2_ascii
clear

load file2_ascii


% file_string_ascii
clear 

load ('file_string_ascii', 'aa', 'bb')


% file1
clear

load('file1')