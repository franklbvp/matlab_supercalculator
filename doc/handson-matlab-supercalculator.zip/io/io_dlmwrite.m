% 
% Delimited Write 
% The MATLAB command used to write data
% separated by a tab is 'dlmwrite'
%     dlmwrite(filename,m,dlm)
%      array containing the data
%      name of file in single quotes
%      Delimiter '/t' for tab
%
clear;
a=dlmread('data2.csv',',');
dlmwrite('newfile.txt',a,'-');
