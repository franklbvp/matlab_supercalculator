%
% demo writing to .xls
%
%
xlswrite('testdata', [12.7 5.02 -98 63.9 0 -.2 56])

m = rand(100,4);
header = {'my data'};
    %header{1} = 'first line';      %This will give
    %header{2} = 'second line';     % 2 header lines
colnames = {'Ch1','Ch2','Ch3','Ch4'};
 
% save the spreadsheet as myfile.xls.  
xlswrite('myfile',header,'Sheet1', 'A1');
xlswrite('myfile',colnames,'Sheet1', 'A2');
xlswrite('myfile',m,'Sheet1', 'A3');
