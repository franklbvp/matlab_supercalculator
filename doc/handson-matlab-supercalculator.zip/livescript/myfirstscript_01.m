%
% this is a script
% calculate the sum and the product
%
a = 1;
b = 2.2; % very important value
c = a + b;
d = a * b;