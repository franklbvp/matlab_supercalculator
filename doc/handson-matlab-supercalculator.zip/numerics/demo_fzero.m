%
% demo fzero
%
% f(x)=(x^3)cos(x)-4
%
%
% plot the function
%
x=-5:0.05:5;
plot(x,myf(x));
grid on

%
% find zero
%
zp5 = fzero('myf',5, optimset('TolX',0.00001,'Display','iter'))
zm2 = fzero('myf',-2, optimset('TolX',0.001,'Display','iter'))
zm5 = fzero('myf',-5, optimset('TolX',0.001,'Display','iter'))
