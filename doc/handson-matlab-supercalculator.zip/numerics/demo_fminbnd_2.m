%
% f(x) = -exp(-x^2)
%
x=-3:0.01:3;
y=-exp(-x.^2);
plot(x,y);

X=fminbnd('-exp(-x^2)',-2,2)
