% 
% example first order ode
%
% driver for 
% x'(t)=sin(tx(t)) with x(0)=1 for 0 < t < 20.
%
% based on Bruce Driver example
%

%
%[T,Y] = solver(odefun,tspan,y0)
%
[t,x]=ode45('firstode',[0,20],1); 

plot(t,x) 

grid on

title('Solution to x''=sin(tx), x(0)=1') 

