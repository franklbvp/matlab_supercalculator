%
% demo elementary data analysis functions
%

% put some data in an array

WDATA=[
110 10.1 7.2
111 12.6 8.7
112 15.2 8.2
113 18.7 8.6
114 9.1 2.5
115 3.5 0.1
116 6.8 1.7
117 9.2 3.8 ];

% detect the size of data 
size(WDATA)
[m,n] = size(WDATA)
a = size(WDATA)

% maximum
% the argument is a full-fledged matrix; 
% the result is a row vector containing the maximum values of each column
max(WDATA)

% In this case the argument is a vector, the second column of the WDATA matrix
max(WDATA(:,2))

max(max(WDATA))

% minimum
min(WDATA(:,3))
min(WDATA)
min(min(WDATA))

% mean
mean(WDATA(:,3))
mean(WDATA)
mean(mean(WDATA))

%median
median(WDATA(:,2))
median(WDATA)
median(median(WDATA))

%std
std(WDATA(:,3))
std(WDATA)

% sort
% Note that the three columns of the matrix are sorted independently 
% so that the data items in the rows are no longer related
sort(WDATA(:,3))
sort(WDATA)


% sum
sum(WDATA(:,3))
sum(WDATA)
sum(sum(WDATA))

% prod
prod(WDATA(:,3))
prod(WDATA)
prod(prod(WDATA))

% cumsum
cumsum(WDATA(:,3))
cumsum(WDATA)

% cumprod
cumprod(WDATA(:,3))
cumprod(WDATA)

% hist
hist(WDATA(:,2))
hist(WDATA(2:7,3))

% corrcoef
% These are LINEAR correlation coefficients for each possible set of two variables. 
% Note that the result is a symmetric matrix with all elements on the diagonal equal to one. 
% That's not too surprising; each of the three variables is perfectly correlated with itself. 
% Considering the data, the correlation coefficient (2,3) or (3,2) in the matrix is probably 
% the most meaningful. 
% This is the correlation between the maximum temperature and the number of hours of sunshine 
% per day. They are strongly correlated (0.8862) although it is not clear 
% if the correlation is significant.

corrcoef(WDATA)
corrcoef(WDATA(2:7,2:3))

% cov
cov(WDATA(:,2))
cov(WDATA)
