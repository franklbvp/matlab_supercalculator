% minimise f(x,y) = (x-1)^2 + y^2 +3
clc
clear
close all

[x1,y1]=meshgrid(-5:0.05:5,-5:0.05:5);
z1 = (x1-1).^2+y1.^2+3;
mesh(x1, y1, z1);
hold on;
[xpoint, fval] = fminsearch(@myfun2D, [1,2])

plot3(xpoint(1), xpoint(2), fval, 'o');