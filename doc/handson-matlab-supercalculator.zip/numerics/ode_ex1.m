% ODE Example 1
% EF 230 Spring, 2011
% http://ef.engr.utk.edu/ef230-2013-01/modules/matlab-ode/

function ode_ex1
 
%% 1 - Develop a numeric solution to a simple ODE and compare to analytic solution
% solve dy/dt = cos(t)
clear all, close all, clc, format compact, format long g
%
timerange = [0 2*pi]; % range of times to solve for
y0 = 2; % initial value
 
[tpts,ypts] = ode45(@ydotfunc,timerange,y0); % solve, return solution points
plot(tpts,ypts,'ro')
 
% analytic solution
anal = @(t)(sin(t)+2);
hold on
ta=linspace(0,2*pi,200);
ya=anal(ta);
plot(ta,ya,'-');
title('dy/dt = cos(t)');
xlabel('t')
ylabel('y')
legend('ode45 points','exact solution');
 
% compare points
analpts = anal(tpts);
errlist = abs((ypts-analpts)./analpts);
 
msg=sprintf('max error = %g\n',max(errlist));
 
waitfor(msgbox(msg));
 
end % ode_ex1
 
% function for ode45
function yp = ydotfunc(t,y)
yp = cos(t);
end %ydotfunc