% 
%
% example script MathWorks
% showing NaN
%

% Import the sample data
% - does not work with load
x_tot = importdata('temp3city_missing.dat');

% Keep all the numbers, remove the non-numbers
% find makes it linear!
i = find(~isnan(x_tot));
x = x_tot(i);

% code for keeping a matrix and removing the rows with NaN
x_clean = x_tot;
x_clean(any(isnan(x_clean),2),:) = [];
