%
% demo taken from D. Smith - Engineering Computation
%
clear all; close all; clc;

x = 0:5;
y = [0 20 60 68 77 110];
y2 = 20 * x;

plot(x, y, 'o');
hold on

plot(x, y2, 'k');
%
% use the built-in function
%
p=polyfit(x,y,1);    
yp = polyval(p,x);
hold on
plot(x, yp, 'r');

axis([-1 7 -20 120])
title('Linear estimate')
xlabel('Time (sec)')
ylabel('Temperature (F)')
legend ('data', 'straight-eyeball', 'polyfit', 'location', 'NorthWest')
grid
