%
% example of data treatment
% 
% http://www-h.eng.cam.ac.uk/help/tpl/programs/Matlab/matlabbyexample/
%

clear
clc

% read the data file data.txt

load data.txt


whos

% some matrix manipulations

s=size(data)

data(:,1)       % shows the 1st column. data(1,:) shows the 1st row. data(:) returns all the elements as a single column.
data2=data+5    % returns a new array whose elements are each 5 more than data's elements.
data+data2      % adds the matrices
data'           % returns the transpose of data. Typing size(data') shows you the size of the transpose
data' * data    % multiplies a 3x106 matrix by a 106x3 matrix to give a 3x3 matrix.
data.*data2     % multiplies each element in data by the corresponding element in data2. The matrices need to be the same size.


% Matrix functions
% Matlab has many functions. To find out more about a particular function, type help followed by the function name.

sum(data)       % sums each column.
mean(data)      % finds the mean of each column. mean(data(:)) would find the mean of the whole matrix (though that's not useful to us in this situation).
max(data)       % finds the maximum number in each column

% Eliminate outliers and duplicates
% Any experimental data is likely to contain erroneous or duplicate data. Here we'd first like to eliminate duplicate rows. Whenever you want to find out how to do something and you can think up a keyword you can use lookfor. So
%
%   lookfor duplicate
%   lookfor unique
%

% create a new matrix with unique rows. It also sorts the rows
udata=unique(data,'rows');

% Let's suppose that all z data less than -5 is bogus. We'll set these values to 0. One way to do this would be to use a for loop checking each value much as in a language like Fortran. Here's the code to do that
% [rows,cols]=size(udata) for i=1:rows if(udata(i,3) < -5) udata(i,3) = 0 end end
% but there's a quicker way, using the find command.

toosmall=find(udata< -5)
udata(toosmall)=0

% Show the z values as a 2D surface
% Let's first create some vectors to aid code legibility
xvalues=udata(:,1); yvalues=udata(:,2); zvalues=udata(:,3);

plot3(xvalues, yvalues, zvalues ,'.')


% The results aren't easy to visualize. We'd like a surface. For that we need to do more work because some of the more useful matlab commands require the data to be on a regular grid. You can prepare this data for use with the griddata command
% First define a regular grid. 
% We'll set up a 20x20 grid 
steps = linspace(-1,1, 20); [XI,YI] = meshgrid(steps, steps); 
% XI and YI will both be 20x20. XI contains the x-coords of each point 
% on this new grid, and YI contains the y-coords. 
% now interpolate - find z values at each of these grid points 
ZI = griddata(xvalues, yvalues, zvalues,XI, YI); 

% Display this as a surface 
surf(XI,YI,ZI); 
hold on ; % this stops the next command clearing the graphics window 
% plot the original data too 
plot3(xvalues, yvalues, zvalues,'.')


% Note that during interpolation, matlab warned that the data contained lines that have different z values for the same (x,y) point. It used the mean z in such situations.
% Find a best-fit mathematical function for the data
% We might already have in mind a model for the data. For this data, the z values peak at (0.0) and seem to depend on x periodically, so I'm going to try to fit the data to a formula like this
%
%  A1*sin(A2*x) + A3./sqrt(0.5+x.^2 + y.^2);
%
% and I'd like to find constants A1, A2, and A3 such that the values of this expression are as close to z as possible. Matlab has several optimisation routines. 
% I'm going to use lsqnonlin (which you might not have - see later). To use this we have to set the problem up appropriately. We need to specify initial conditions and an expression to minimize. The optimisation functions are rather technical, so I won't go into details - they're online.
a0=[10 10 10 ]; % initial conditions for A1, A2 and A3 - just a guess 
% the next line uses 'anonymous functions'. It sets up a function f % that takes a (containing A1, A2, A3) as input. % It's this function that will be minimized 
f=@(a) a(1)*sin(a(2)*XI) + a(3)./(0.5+sqrt(XI.^2+YI.^2)) -ZI; % here we can choose options for the optimisation routine. 
options=optimset('Display','iter'); % now we optimise. The returned af vector will contain the A1, A2, and A3 we want 
af=lsqnonlin(f,a0,[],[], options)

% When I run this I get
af = [3.2388 10.0295 7.6435];
% Is this a good fit? Let's see
Ztheoretical= af(1) * sin(af(2)*XI) + af(3)./(0.5 + sqrt(XI.^2+YI.^2)); 
max(Ztheoretical(:)-ZI(:)) 
mean(Ztheoretical(:)-ZI(:))

% Let's also see this visually. We'll add the theoretical results as a grid. We'll also add titles, and save the result in a jpeg file.
close; % clear the graphics 
surf(XI,YI,Ztheoretical); 
title('best fit'); 
xlabel('x'); 
ylabel('y'); 
colorbar; % add a color-coded key to z values 
print -djpeg -zbuffer demo1.jpg

get(gca)

titlehandle=get(gca,'Title');
set(titlehandle,'FontSize',20);

% Save the resulting data
% Suppose we wanted to store the cleaned, interpolated values in XI, ZI, and ZI. We could do save XI YI ZI 'newdata.txt' but that would save all the elements in the matrices. 
%If we wanted to save in a file with the same form as the original we need to use lower level commands which are like those of the C language.
fp=fopen('newdata.txt','w'); 
[rows,cols]=size(XI); 
for i=1:rows 
    for j=1:cols 
        fprintf('%f %f %f \n', XI(i,j), YI(i,j), Ztheoretical(i,j)); 
    end
end
fclose(fp);
