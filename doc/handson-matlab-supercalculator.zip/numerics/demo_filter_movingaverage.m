%
% Mathworks example
%
% A moving-average filter is a common method used for smoothing noisy data. 
% This example uses the filter function to compute averages along a vector of data.

% Create a 1-by-100 row vector of sinusoidal data that is corrupted by random noise.
t = linspace(-pi,pi,100);
rng default  %initialize random number generator
x = sin(t) + 0.25*rand(size(t));

% moving average of windowSize
windowSize = 5; 
b = (1/windowSize)*ones(1,windowSize);
a = 1;

% apply the filter function
y = filter(b,a,x);

plot(t,x)
hold on
plot(t,y)
legend('Input Data','Filtered Data')