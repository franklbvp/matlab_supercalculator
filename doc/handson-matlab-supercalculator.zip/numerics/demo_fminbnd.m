%
% minimize x^3 - x^2sin(x) in the interval [-1.2  2.8]
%
% developed in R2017a

clear
clc
close all

x = [-2:0.01:3];
y1 = x.^3;
y2 = x.^2;
y = y2.*sin(x);
y = y1 - y;
plot(x, y)


fminbnd('x.^3-x.^2*sin(x)', -1.2, 2.8)

%{
% or
fun=inline(�x.^3-x.^2*sin(x)�)
fminbnd(fun, -1.2, 2.8)
% or 
fun=�x.^3-x.^2*sin(x)�
fminbnd(fun, -1.2, 2.8)
%}