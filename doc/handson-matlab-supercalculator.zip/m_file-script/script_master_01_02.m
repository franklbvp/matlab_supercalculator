% 
% main script calling 2 other scripts
%

script_01

script_02