% script M-file script_02.m

shoes = 7;
sock = 100;
bag = input('enter number of bags:');
items = shoes + sock + bag
cost = shoes * 25 + sock * 2 + bag * 50
cost_avg = cost / items