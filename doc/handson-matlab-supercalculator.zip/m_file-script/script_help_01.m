% script M-file script_help_01.m special keyword supercritical
%
% this is a small script showing some help features
%
% Author: x
%
% check the comments
% help help_script_01

%echo on

shoes = 4;
sock = 10;
bag = 5;


shoes

disp(shoes);

%beep

shoes = input('enter number of shoes');
items = shoes + sock + bag

%pause(2);

cost = shoes * 25 + sock * 2 + bag * 50


cost_avg = cost / items

%echo off