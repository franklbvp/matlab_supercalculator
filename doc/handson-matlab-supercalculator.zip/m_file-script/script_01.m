% script M-file script_01.m

%echo on

shoes = 4;
sock = 10;
bag = 5;


shoes

disp(shoes);


shoes = input('enter number of shoes');
items = shoes + sock + bag


cost = shoes * 25 + sock * 2 + bag * 50
 

cost_avg = cost / items

%echo off