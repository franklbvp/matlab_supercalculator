% Anscombe quartet
%
%{
The four sets of data that make up the quartet are similar in many respects. For all four:

mean of the x values = 9.0
mean of the y values = 7.5
equation of the least-squared regression line is: y = 3 + 0.5x
sums of squared errors (about the mean) = 110.0
regression sums of squared errors (variance accounted for by x) = 27.5
residual sums of squared errors (about the regression line) = 13.75
correlation coefficient = 0.82
coefficient of determination = 0.67
%}

x1=[10 8 13 9 11 14 6 4 12 7 5];
x2=x1;
x3=x1;
x4=[8 8 8 8 8 8 8 19 8 8 8];

y1=[8.04 6.95 7.58 8.81 8.33 9.96 7.24 4.26 10.84 4.82 5.68];
y2=[9.14 8.14 8.74 8.77 9.26 8.1 6.13 3.1 9.13 7.26 4.74];
y3=[7.46 6.77 12.74 7.11 7.81 8.84 6.08 5.39 8.15 6.42 5.73];
y4=[6.58 5.76 7.71 8.84 8.47 7.04 5.25 12.5 5.56 7.91 6.89];

anscombe1 = [x1' y1']; 

anscombe2 = [x2' y2'];

anscombe3 = [x3' y3'];
    
anscombe4 = [x4' y4'];

anscombe = [anscombe1 anscombe2 anscombe3 anscombe4];

sum(anscombe)

mean(anscombe)

xdraw = [4:19]

pp1 = polyfit(x1,y1,1);
yp1 = polyval(pp1, xdraw);

pp2 = polyfit(x2,y2,1);
yp2 = polyval(pp2, xdraw);

pp3 = polyfit(x3,y3,1);
yp3 = polyval(pp3, xdraw);

pp4 = polyfit(x4,y4,1);
yp4 = polyval(pp4, xdraw);


figure 
ps(1)=subplot(2, 2, 1);
scatter(x1, y1);
hold on;
plot(xdraw, yp1, 'r');

ps(2)=subplot(2, 2, 2)
scatter(x2, y2)
hold on;
plot(xdraw, yp2, 'r');

ps(3)=subplot(2, 2, 3)
scatter(x3, y3)
hold on;
plot(xdraw, yp3, 'r');

ps(4)=subplot(2, 2, 4)
scatter(x4, y4)
hold on;
plot(xdraw, yp4, 'r');

%put the axes on the same value
linkaxes(ps, 'xy');
